import cabutils

#LOC @ 1

#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   07.01.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Synopsis:   Nieve code generator for compiled "freeze" file, icemode.py,
#                of business logic derived from the architectural control 
#                language (ACL) file, directory.scsv.
#
#    Entry:      main()
#
#    Data    :   None
#    Behavior:   Outputs icemode.py.
#
#    Input   :   None
#    Output  :   Default Return Code
#    See     :   PRIMARY_SCRIPT Below


#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  12.18.2020
#    Modified:  -
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  build_read_file
#
#    Data    :  None
#		        
#    Behavior:  Echos "def read_file(...)" Source.
#
#    Input   :   None
#    Output  :   Echos Text

def build_file_read():

    print("def read_file( file_name ):")
    print("\ttry:")
    print("\t\tfile_handle = open(file_name)")
    print("\t\tresponse = file_handle.read()")
    print("\t\tfile_handle.close()")
    print("\texcept IOError:")
    print("\t\tresponse = \"Error reading file: \" + file_name")
    print("\treturn response")

    return

#LOC @ 11

#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  12.18.2020
#    Modified:  -
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  build_view_switch
#
#    Data    :  None
#		        
#    Behavior:  Echos "def get_view(...)" Source.
#
#    Input   :   views
#    Output  :   Echos Text

def build_view_switch( views ):

    print("def get_view( view_id ):")
    print("\tresponse = \"\"")

    for key, value in views.items():
        print("\tif ( view_id == \""+ key +"\" ):")
        print("\t\tresponse = read_file(\""+value+"\")")

    print("\treturn response")

    return

#LOC @ 19

#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  12.18.2020
#    Modified:  -
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  build_placeholder_switch
#
#    Data    :  None
#		        
#    Behavior:  Echos "def get_placeholders(...)" Source.
#
#    Input   :   placeholders
#    Output  :   Echos Text

def build_placeholder_switch( placeholders ):

    print("def get_placeholders( view_id ):")
    print("\tresponse = []")

    for key, value in placeholders.items():
        print("\tif ( view_id == \""+ key +"\" ):")
        print("\t\tresponse = "+str(value) )

    print("\treturn response")

    return

#LOC @ 27

def main():

    views, placeholders = cabutils.build_logic()
        
    build_file_read()
    print("\n\n#BEGIN - GENERATED FILE\n\n")
    build_view_switch( views )
    print("\n\n\n\n")
    build_placeholder_switch( placeholders )
    print("\n\n#END - GENERATED FILE\n\n")
        
    return

#LOC @ 35

#PRIMARY SCRIPT
#invoke main entry-point
if ( __name__ == "__main__" ):
    main()

#LOC @ 37    