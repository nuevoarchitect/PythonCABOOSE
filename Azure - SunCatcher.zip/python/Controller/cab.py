import cgi
from datetime import datetime
#replacements

#B VIEW
def get_datetime():
    return( str(datetime.now()) )

#C VIEW
def get_ducks():

    form = cgi.FieldStorage()
    rest_csv = form.getvalue( "rest" )
    rest_list = rest_csv.split(",")

    the_array = "['" + rest_list[0] + "','"+ rest_list[1] + "','"+ rest_list[2] + "'];"

    return( the_array )

