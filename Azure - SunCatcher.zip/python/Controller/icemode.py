def read_file( file_name ):
	try:
		file_handle = open(file_name)
		response = file_handle.read()
		file_handle.close()
	except IOError:
		response = "Error reading file: " + file_name
	return response


#BEGIN - GENERATED FILE


def get_view( view_id ):
	response = ""
	if ( view_id == "home" ):
		response = read_file("C:/dev/python/StoryBoard/home.html")
	if ( view_id == "A" ):
		response = read_file("C:/dev/python/StoryBoard/stepA.html")
	if ( view_id == "B" ):
		response = read_file("C:/dev/python/StoryBoard/stepB.html")
	if ( view_id == "C" ):
		response = read_file("C:/dev/python/StoryBoard/stepC.html")
	if ( view_id == "error" ):
		response = read_file("C:/dev/python/StoryBoard/error.html")
	return response





def get_placeholders( view_id ):
	response = []
	if ( view_id == "A" ):
		response = [('#PYTHON_DATE#', 'NON_OO', 'get_datetime')]
	if ( view_id == "B" ):
		response = [('#DUCKS_IN_A_ROW#', 'NON_OO', 'get_ducks')]
	return response


#END - GENERATED FILE


