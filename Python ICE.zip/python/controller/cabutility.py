#BEGIN GLOBALS

#Standard location for CABOOSE Logic File
CABOOSE_LOGIC = "C:/dev/python/storyboard/directory.scsv"

#CSV positions for section markers 
BEGIN = 0
END = 0
SECTION = 1

#CSV position for view section
VIEW_ID = 0
TEMPLATE = 1

#CSV positions for placeholder section
#VIEW_ID = 0 reused from above
STENCIL = 1
CLASS = 2
METHOD = 3

#Tuple positions for placeholder replacement logic
LOGIC_STENCIL = 0
LOGIC_CLASS = 1
LOGIC_METHOD = 2

#END GLOBALS


#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  06.20.2020
#    Modified:  12.18.2020
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  read_file
#
#    Data    :  File 	file_handle
#		        String	response
#    Behavior:  Returns Stencil HTML from StoryBoard or "Error reading file: #FILE_NAME#".
#
#    Input   :   file_name
#    Output  :   response

def read_file( file_name ):

    try:

        file_handle = open(file_name)
        response = file_handle.read()
        file_handle.close()

    except IOError:

        response = "Error reading file: " + file_name

    return response

#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   09.06.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :   build_logic
#
#    Data    :   None
#    Behavior:   Parses Logic File and Builds View and Placeholder Logic Dictionaries.
#
#    Input   :   None
#    Output  :   View and Placeholder Logic Dictionaries

def build_logic():

    views = {}
    placeholders = {}

    in_views = False
    in_placeholders = False

    logic = read_file(CABOOSE_LOGIC)
    lines = logic.split("\n")

    for line in lines:

        line = line.strip()

        if( len(line) > 0 and line[0] != '?' ):

            tokens = line.split(",")

            if ( tokens[BEGIN].upper().strip() == "BEGIN" and tokens[SECTION].upper().strip() == "VIEWS" ):
                in_views = True
                continue

            if ( tokens[END].upper().strip() == "END" and tokens[SECTION].upper().strip() == "VIEWS" ):
                in_views = False
                continue

            if ( tokens[BEGIN].upper().strip() == "BEGIN" and tokens[SECTION].upper().strip() == "PLACEHOLDERS" ):
                in_placeholders = True
                continue

            if ( tokens[END].upper().strip() == "END" and tokens[SECTION].upper().strip() == "PLACEHOLDERS" ):
                in_placeholders = False
                continue

            if ( in_views and ( tokens[VIEW_ID].upper().strip() != "VIEWID" ) ):
                views[ tokens[ VIEW_ID ].strip() ] = tokens[ TEMPLATE ].strip()

            if ( in_placeholders and ( tokens[VIEW_ID].upper().strip() != "VIEWID" ) ):
                if ( tokens[ VIEW_ID ].strip() not in placeholders ):
                    placeholders[ tokens[ VIEW_ID ].strip() ] = []
                placeholders[ tokens[ VIEW_ID ].strip() ].append( ( tokens[ STENCIL ].strip() , tokens[ CLASS ].strip() , tokens[ METHOD ].strip() ) )

    return( views, placeholders )
