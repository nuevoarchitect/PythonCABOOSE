#IMPORTS - BEGIN
try:
	import cabutility as cab_utils
except ImportError as e:
	print("Content-type: text/plain")
	print("")
	print("[IMPORT ERROR]: Controller Utility Package Missing (cabutility.py) missing.\n")
	print("Place this module within the default import path.\n\n")
	print("[SYSTEM MESSAGE]: {0}\n".format(e)  )
	sys.exit()
#IMPORTS - END





def get_view( view_id ):
	response = ""
	if ( view_id == "home" ):
		response = cab_utils.read_file("C:/dev/python/storyboard/main.html")
	elif ( view_id == "landing" ):
		response = cab_utils.read_file("C:/dev/python/storyboard/portal.html")
	elif ( view_id == "error" ):
		response = cab_utils.read_file("C:/dev/python/storyboard/error.html")
	return response





def get_placeholders( view_id ):
	response = []
	if ( view_id == "home" ):
		response = [('#BODY#', 'NON_OO', 'get_body'), ('#TITLE#', 'NON_OO', 'get_title')]
	elif ( view_id == "landing" ):
		response = [('#USER_ID#', 'NON_OO', 'get_user_id'), ('#MESSAGE#', 'NON_OO', 'get_message'), ('#TITLE#', 'NON_OO', 'get_title')]
	elif ( view_id == "error" ):
		response = [('#ERROR_MESSAGE#', 'NON_OO', 'get_error'), ('#TITLE#', 'NON_OO', 'get_title')]
	return response
