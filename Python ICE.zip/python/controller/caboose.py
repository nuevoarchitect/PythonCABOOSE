#IMPORTS - BEGIN
import sys
import cgi, cgitb

#user-defined imports
try:
    import icemode
except ImportError as e:
    pass

try:
    import cab as cab_replacements
except ImportError as e:
    print("Content-type: text/plain")
    print("")
    print("[IMPORT ERROR]: Controller Application Bundle (cab.py) missing.\n")
    print("Place CABOOSE controller support functionality in cab.py.")
    print("And, place this module within the default import path.\n\n")
    print("[SYSTEM MESSAGE]: {0}\n".format(e)  )
    sys.exit()

try:
    import cabutility as cab_utils
except ImportError as e:
    print("Content-type: text/plain")
    print("")
    print("[IMPORT ERROR]: Controller Utility Package Missing (cabutility.py) missing.\n")
    print("Place this module within the default import path.\n\n")
    print("[SYSTEM MESSAGE]: {0}\n".format(e)  )
    sys.exit()

#IMPORTS - END

#GLOBALS - BEGIN

#Standard Error File
STANDARD_ERROR = "error"

#HI PERFORMACE MODE
try:
    ICEMODE = cab_replacements.ICEMODE
except AttributeError as e:
    ICEMODE = False

#GLOBALS - END


#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   07.01.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Data    :   None
#    Behavior:   Outputs HTML Requested With "view_id".
#            :   This is a general-purpose portion of a unviersal controller
#            :   for MVC use on the web or in a command-line interface
#            :   It must be supported by a "cab.py" file which populates 
#            :   the view concerns found among the "markup-language" templates
#            :   in the StoryBoard directory.
#
#    Input   :   view_id, form_data
#    Output  :   Default Return Code
#    See     :   PRIMARY_SCRIPT Below


#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   06.26.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :   fill_view
#
#    Data    :   None
#		       
#    Behavior:   Returns Populated Template or "Error reading file: #FILE_NAME#".
#
#    Input   :   response, placeholders
#    Output  :   response

def fill_view( response, placeholders, form ):

    for placeholder in placeholders:
        response = response.replace(placeholder[cab_utils.LOGIC_STENCIL] , eval( "cab_replacements." + placeholder[cab_utils.LOGIC_METHOD] + "( form )" ) )

    return response


#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   06.19.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :   send_response
#
#    Data    :   None
#    Behavior:   Echos a Populated Template from the StoryBoard or an Exception Message.
#
#    Input   :   None
#    Output  :   Default Return Code

def send_response():

    print("Content-type: text/html\n")

    form = cgi.FieldStorage()

    view_id = form.getvalue("view")

    if( len( sys.argv ) > 1 ):
        view_id = sys.argv[1].strip()

    views, placeholders = cab_utils.build_logic()

    if ( view_id not in views ):
        view_id = STANDARD_ERROR

    if ( ICEMODE is True ):
        print( fill_view( icemode.get_view(view_id), icemode.get_placeholders(view_id), form ) )
    else:
        print( fill_view( cab_utils.read_file( views[view_id] ), placeholders[ view_id ], form ) )

#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   06.19.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :   main
#    Data    :   None
#    Behavior:   Invokes send_response.
#
#    Input   :   Command-line arguments (Discarded)
#    Output  :   Default Return Code

def main():

    send_response()

#PRIMARY_SCRIPT
#invoke main entry-point
if ( __name__ == "__main__" ):
    main()
