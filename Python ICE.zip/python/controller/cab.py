
#This is the Python file which supports the behavior found in 
#caboose.py. It helps provide the "special-purpose" function for the
#particular application which the general-purpose controller is supporting

#See "directory.scsv" for a description of the CABOOSE MAPPING LOGIC

#HI-PERFORMANCE CONSTANT - Recommended [True|False]
ICEMODE = True

#replacements

#ALL VIEWS
def get_title( form = None ):
    return( "NuevoArchitect | Vision Factory |  VIEW - " + form.getvalue("view") )

#HOME VIEW
def get_body( form = None ):
    return( "Hello, World!" )

#ERROR VIEW
def get_error( form = None ):
    return( "Oh! Snafu" )

#LANDING VIEW
def get_user_id( form = None ):
    return( "bgates" )

def get_message( form = None ):
    return( "Let's visit Microsoft: <a href='http://www.microsoft.com'>Proceed</a>" )