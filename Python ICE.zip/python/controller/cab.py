
#This is the Python file which supports the behavior found in 
#caboose.py. It helps provide the "special-purpose" function for the
#particular application which the general-purpose controller is supporting

#See "directory.scsv" for a description of the CABOOSE MAPPING LOGIC

#HI-PERFORMANCE CONSTANT - Recommended [True|False]
ICEMODE = False

#replacements

#ALL VIEWS
def get_title():
    return( "NuevoArchitect | Vision Factory" )

#HOME VIEW
def get_body():
    return( "Hello, World!" )

#ERROR VIEW
def get_error():
    return( "Oh! Snafu" )

#LANDING VIEW
def get_user_id():
    return( "bgates" )

def get_message():
    return( "Let's visit Microsoft: <a href='http://www.microsoft.com'>Proceed</a>" )