#This document is a utility script used for building the icemode.py file.
#It will "freeze" the dynamic nature of the CABOOSE system. 
#This will expedite processing if ICEMODE = True in caboose.py

#IMPORTS - BEGIN

try:
    import cabutility as cab_utils
except ImportError as e:
    print("Content-type: text/plain")
    print("")
    print("[IMPORT ERROR]: Controller Utility Package Missing (cabutility.py) missing.\n")
    print("Place this module within the default import path.\n\n")
    print("[SYSTEM MESSAGE]: {0}\n".format(e)  )
    sys.exit()

#IMPORTS - END

#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  12.18.2020
#    Modified:  -
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  build_read_file
#
#    Data    :  None
#		        
#    Behavior:  Echos "def read_file(...)" Source.
#
#    Input   :   None
#    Output  :   Echos Text

#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  01.10.2021
#    Modified:  -
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  build_imports
#
#    Data    :  None
#		        
#    Behavior:  Echos "...import cabutility as ..." Source.
#
#    Input   :   None
#    Output  :   Echos Text

def build_imports():
    print("#IMPORTS - BEGIN")
    print("try:")
    print("\timport cabutility as cab_utils")
    print("except ImportError as e:")
    print('\tprint("Content-type: text/plain")')
    print('\tprint("")')
    print('\tprint("[IMPORT ERROR]: Controller Utility Package Missing (cabutility.py) missing.\\n")')
    print('\tprint("Place this module within the default import path.\\n\\n")')
    print('\tprint("[SYSTEM MESSAGE]: {0}\\n".format(e)  )')
    print('\tsys.exit()')
    print("#IMPORTS - END")

#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  12.18.2020
#    Modified:  -
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  build_view_switch
#
#    Data    :  None
#		        
#    Behavior:  Echos "def get_view(...)" Source.
#
#    Input   :   views
#    Output  :   Echos Text

def build_view_switch( views ):

    print("def get_view( view_id ):")
    print("\tresponse = \"\"")

    first = True
    for key, value in views.items():
        if( first ):
            print("\tif ( view_id == \""+ key +"\" ):")
            print("\t\tresponse = cab_utils.read_file(\""+value+"\")")
            first = False
        else:
            print("\telif ( view_id == \""+ key +"\" ):")
            print("\t\tresponse = cab_utils.read_file(\""+value+"\")")
            

    print("\treturn response")

    return

#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  12.18.2020
#    Modified:  -
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  build_placeholder_switch
#
#    Data    :  None
#		        
#    Behavior:  Echos "def get_placeholders(...)" Source.
#
#    Input   :   placeholders
#    Output  :   Echos Text

def build_placeholder_switch( placeholders ):

    print("def get_placeholders( view_id ):")
    print("\tresponse = []")

    first = True
    for key, value in placeholders.items():
        if (first):
            print("\tif ( view_id == \""+ key +"\" ):")
            print("\t\tresponse = "+str(value) )
            first = False
        else:
            print("\telif ( view_id == \""+ key +"\" ):")
            print("\t\tresponse = "+str(value) )
            

    print("\treturn response")

    return

def main():

    views, placeholders = cab_utils.build_logic()

    build_imports()
    print("\n\n\n\n")
    build_view_switch( views )
    print("\n\n\n\n")
    build_placeholder_switch( placeholders )
        
    return

#PRIMARY SCRIPT
#invoke main entry-point
if ( __name__ == "__main__" ):
    main()

    