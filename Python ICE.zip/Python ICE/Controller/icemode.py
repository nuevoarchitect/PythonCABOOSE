def read_file( file_name ):
	try:
		file_handle = open(file_name)
		response = file_handle.read()
		file_handle.close()
	except IOError:
		response = "Error reading file: " + file_name
	return response





def get_view( view_id ):
	response = ""
	if ( view_id == "home" ):
		response = read_file("./../StoryBoard/main.html")
	elif ( view_id == "landing" ):
		response = read_file("./../StoryBoard/portal.html")
	elif ( view_id == "error" ):
		response = read_file("./../StoryBoard/error.html")
	return response





def get_placeholders( view_id ):
	response = []
	if ( view_id == "home" ):
		response = [('#BODY#', 'NON_OO', 'get_body'), ('#TITLE#', 'NON_OO', 'get_title')]
	elif ( view_id == "landing" ):
		response = [('#USER_ID#', 'NON_OO', 'get_user_id'), ('#MESSAGE#', 'NON_OO', 'get_message'), ('#TITLE#', 'NON_OO', 'get_title')]
	elif ( view_id == "error" ):
		response = [('#ERROR_MESSAGE#', 'NON_OO', 'get_error'), ('#TITLE#', 'NON_OO', 'get_title')]
	return response
