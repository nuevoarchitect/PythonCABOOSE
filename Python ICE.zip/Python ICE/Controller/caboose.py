import cab as cab_replacements
import icemode 
import sys

#GLOBALS - BEGIN

#Standard location for CABOOSE Logic File
CABOOSE_LOGIC = "./../StoryBoard/directory.scsv"

#CSV positions for section markers 
BEGIN = 0
END = 0
SECTION = 1

#CSV position for view section
VIEW_ID = 0
TEMPLATE = 1

#CSV positions for placeholder section
#VIEW_ID = 0 reused from above
STENCIL = 1
CLASS = 2
METHOD = 3

#Tuple positions for placeholder replacement logic
LOGIC_STENCIL = 0
LOGIC_CLASS = 1
LOGIC_METHOD = 2

#Standard Error File
STANDARD_ERROR = "error"

#HI PERFORMACE MODE
ICEMODE = True

#GLOBALS - END


#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   07.01.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Data    :   None
#    Behavior:   Outputs HTML Requested With "view_id".
#            :   This is a general-purpose portion of a unviersal controller
#            :   for MVC use on the web or in a command-line interface
#            :   It must be supported by a "cab.py" file which populates 
#            :   the view concerns found among the "markup-language" templates
#            :   in the StoryBoard directory.
#
#    Input   :   view_id, query
#    Output  :   Default Return Code
#    See     :   PRIMARY_SCRIPT Below



#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   09.06.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :   build_logic
#
#    Data    :   None
#    Behavior:   Parses Logic File and Builds View and Placeholder Logic Dictionaries.
#
#    Input   :   None
#    Output  :   View and Placeholder Logic Dictionaries

def build_logic():

    views = {}
    placeholders = {}

    in_views = False
    in_placeholders = False

    logic = read_file(CABOOSE_LOGIC)
    lines = logic.split("\n")

    for line in lines:

        line = line.strip()

        if( len(line) > 0 and line[0] != '?' ):

            tokens = line.split(",")

            if ( tokens[BEGIN].upper().strip() == "BEGIN" and tokens[SECTION].upper().strip() == "VIEWS" ):
                in_views = True
                continue

            if ( tokens[END].upper().strip() == "END" and tokens[SECTION].upper().strip() == "VIEWS" ):
                in_views = False
                continue

            if ( tokens[BEGIN].upper().strip() == "BEGIN" and tokens[SECTION].upper().strip() == "PLACEHOLDERS" ):
                in_placeholders = True
                continue

            if ( tokens[END].upper().strip() == "END" and tokens[SECTION].upper().strip() == "PLACEHOLDERS" ):
                in_placeholders = False
                continue

            if ( in_views and ( tokens[VIEW_ID].upper().strip() != "VIEWID" ) ):
                views[ tokens[ VIEW_ID ].strip() ] = tokens[ TEMPLATE ].strip()

            if ( in_placeholders and ( tokens[VIEW_ID].upper().strip() != "VIEWID" ) ):
                if ( tokens[ VIEW_ID ].strip() not in placeholders ):
                    placeholders[ tokens[ VIEW_ID ].strip() ] = []
                placeholders[ tokens[ VIEW_ID ].strip() ].append( ( tokens[ STENCIL ].strip() , tokens[ CLASS ].strip() , tokens[ METHOD ].strip() ) )

    return( views, placeholders )


#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   06.26.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :   fill_view
#
#    Data    :   None
#		       
#    Behavior:   Returns Populated Template or "Error reading file: #FILE_NAME#".
#
#    Input   :   response, placeholders
#    Output  :   response

def fill_view( response, placeholders ):

    for placeholder in placeholders:
        response = response.replace(placeholder[LOGIC_STENCIL] , eval( "cab_replacements." + placeholder[LOGIC_METHOD] + "()" ) )

    return response


#    Author  :  Jody L. R. Sharpe (NuevoArchitect)
#    Created :  06.20.2020
#    Modified:  12.18.2020
#    License :  CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :  read_file
#
#    Data    :  File 	file_handle
#		        String	response
#    Behavior:  Returns Stencil HTML from StoryBoard or "Error reading file: #FILE_NAME#".
#
#    Input   :   file_name
#    Output  :   response

def read_file( file_name ):

    try:

        file_handle = open(file_name)
        response = file_handle.read()
        file_handle.close()

    except IOError:

        response = "Error reading file: " + file_name

    return response

#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   06.19.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :   send_response
#
#    Data    :   None
#    Behavior:   Echos a Populated Template from the StoryBoard or an Exception Message.
#
#    Input   :   None
#    Output  :   Default Return Code

def send_response():

    view_id = ""

    if( len( sys.argv ) > 1 ):
        view_id = sys.argv[1].strip()

    views, placeholders = build_logic()

    if ( view_id not in views ):
        view_id = STANDARD_ERROR

    if ( ICEMODE is True ):
        print( fill_view( icemode.get_view(view_id), icemode.get_placeholders(view_id) ) )
    else:
        print( fill_view( read_file( views[view_id] ), placeholders[ view_id ] ) )

#    Author  :   Jody L. R. Sharpe (NuevoArchitect)
#    Created :   06.19.2020
#    Modified:   12.18.2020
#    License :   CABOOSE_ROOT/License.pdf (MIT License)
#
#    Name    :   main
#    Data    :   None
#    Behavior:   Invokes send_response.
#
#    Input   :   Command-line arguments (Discarded)
#    Output  :   Default Return Code

def main():

    send_response()

#PRIMARY_SCRIPT
#invoke main entry-point
if ( __name__ == "__main__" ):
    main()
